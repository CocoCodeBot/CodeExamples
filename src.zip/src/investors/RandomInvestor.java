package investors;

import java.util.ArrayList;
import offers.Offer;
import simulation.Market;
import random.RandomGenerator;

public class RandomInvestor extends Investor
{
    public RandomInvestor(int id)
    {
        super(id);
    }

    public Offer createOffer(Market market, int submissionTime)
    {
        Offer.OfferType offerType = Offer.OfferType.values()[RandomGenerator.randomInt(0, 2)]; // 0 - purchase, 1 - sale
        Offer.OfferDeadline offerDeadline = Offer.OfferDeadline.values()[RandomGenerator.randomInt(0, 3)];

        ArrayList<String> shareIDs = market.getShareIDs();
        String randomShareID = shareIDs.get(RandomGenerator.randomInt(0, shareIDs.size()));

        if(getShareAmounts().get(randomShareID) == 0)
            return null;

        int maxAmount = offerType == Offer.OfferType.PURCHASE ? market.countShares(randomShareID) : getShareAmounts().get(randomShareID);
        int sharesAmount = RandomGenerator.randomInt(1, maxAmount + 1);

        int lastPrice = market.getSharePrices().get(randomShareID);
        int priceLimit = RandomGenerator.randomInt(Math.max(1, lastPrice - 10), lastPrice + 11);

        Offer offer = new Offer(this, randomShareID, offerType, offerDeadline, submissionTime, sharesAmount, priceLimit);

        if(offer.getOfferDeadline() == Offer.OfferDeadline.TILL_ROUND)
        {
            offer.setMaxRound(RandomGenerator.randomInt(0, market.getRounds()));
        }

        return offer;
    }
}
