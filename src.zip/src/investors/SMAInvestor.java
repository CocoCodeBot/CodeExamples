package investors;

import java.util.ArrayList;
import offers.Offer;
import simulation.Market;
import random.RandomGenerator;

public class SMAInvestor extends Investor
{
    public SMAInvestor(int id)
    {
        super(id);
    }

    public Offer createOffer(Market market, int submissionTime)
    {
        if(market.getCurrentRound() < 11)
            return null;

        //Offer.OfferType offerType = Offer.OfferType.values()[RandomGenerator.randomInt(0, 2)]; // 0 - purchase, 1 - sale
        Offer.OfferDeadline offerDeadline = Offer.OfferDeadline.values()[RandomGenerator.randomInt(0, 3)];

        ArrayList<String> shareIDs = market.getShareIDs();

        Offer.OfferType offerType = null;
        String finalShareID = null;

        for(String shareID : shareIDs)
        {
            double currentSMA5 = calculateSMA(market, shareID, 5, market.getCurrentRound());
            double currentSMA10 = calculateSMA(market, shareID, 10, market.getCurrentRound());
            double lastSMA5 = calculateSMA(market, shareID, 5, market.getCurrentRound() - 1);
            double lastSMA10 = calculateSMA(market, shareID, 10, market.getCurrentRound() - 1);

            if(getShareAmounts().get(shareID) == 0)
            {
                continue;
            }

            if(lastSMA5 < lastSMA10 && currentSMA5 >= currentSMA10)
            {
                offerType = Offer.OfferType.PURCHASE;
                finalShareID = shareID;
            }
            else if(lastSMA5 > lastSMA10 * lastSMA10 && currentSMA5 <= currentSMA10 * currentSMA10)
            {
                offerType = Offer.OfferType.SALE;
                finalShareID = shareID;
            }
        }

        if(offerType == null)
        {
            return null;
        }
        else
        {
            int maxAmount = offerType == Offer.OfferType.PURCHASE ? market.countShares(finalShareID) : getShareAmounts().get(finalShareID);
            int sharesAmount = RandomGenerator.randomInt(1, maxAmount + 1);

            int lastPrice = market.getSharePrices().get(finalShareID);
            int priceLimit = RandomGenerator.randomInt(Math.max(1, lastPrice - 10), lastPrice + 11);

            return new Offer(this, finalShareID, offerType, offerDeadline, submissionTime, sharesAmount, priceLimit);
        }
    }

    private double calculateSMA(Market market, String shareID, int n, int currentRound)
    {
        double sum = 0;

        for(int i = 1; i <= n; i++)
        {
            sum += market.getPrice(currentRound - i, shareID);
        }

        return sum / (double)n;
    }
}
