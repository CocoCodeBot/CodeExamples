package investors;

import java.util.HashMap;
import offers.Offer;
import simulation.Market;

public abstract class Investor
{
    private int id;
    private int money;
    private HashMap<String, Integer> shareAmounts = new HashMap<>();

    public Investor(int id)
    {
        this.id = id;
    }

    public HashMap<String, Integer> getShareAmounts()
    {
        return shareAmounts;
    }

    public int getMoney()
    {
        return money;
    }

    public void setMoney(int money)
    {
        this.money = money;
    }

    public void addMoney(int q)
    {
        money += q;
    }

    public void addShares(String shareID, int q)
    {
        int s = shareAmounts.get(shareID);
        shareAmounts.put(shareID, s + q);
    }

    public void setShareAmount(String shareName, Integer amount)
    {
        shareAmounts.put(shareName, amount);
    }

    public abstract Offer createOffer(Market market, int submissionTime);

    public String toString()
    {
        StringBuilder s = new StringBuilder();

        s.append(id).append(": ").append(money).append(" ");

        for(String i : shareAmounts.keySet())
        {
            s.append(i).append(":").append(shareAmounts.get(i)).append(" ");
        }

        return s.toString();
    }
}
