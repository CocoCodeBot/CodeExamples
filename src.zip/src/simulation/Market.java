package simulation;

import investors.Investor;
import offers.Offer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;

public class Market
{
    private ArrayList<Investor> investors;
    private HashMap<String, Integer> sharePrices;
    private ArrayList<HashMap<String, Integer>> priceHistory = new ArrayList<>();
    private ArrayList<String> shareIDs;
    private int rounds;
    private int currentRound;
    private ArrayList<Offer> saleOffers = new ArrayList<>();
    private ArrayList<Offer> purchaseOffers = new ArrayList<>();
    private int time; // For offer submissions

    public Market(ArrayList<Investor> investors, HashMap<String, Integer> sharePrices, int rounds)
    {
        this.investors = investors;
        this.sharePrices = sharePrices;
        this.rounds = rounds;

        priceHistory.add(new HashMap<>(sharePrices));
        shareIDs = new ArrayList<>(sharePrices.keySet());
    }

    public int getCurrentRound()
    {
        return currentRound;
    }

    public HashMap<String, Integer> getSharePrices()
    {
        return sharePrices;
    }

    public ArrayList<String> getShareIDs()
    {
        return shareIDs;
    }

    public int getPrice(int roundNumber, String shareID)
    {
        return priceHistory.get(roundNumber).get(shareID);
    }

    public int getRounds()
    {
        return rounds;
    }

    public int countShares(String shareID)
    {
        int amount = 0;

        for(Investor investor : investors)
        {
            amount += investor.getShareAmounts().get(shareID);
        }

        return amount;
    }

    public void simulate()
    {
        for(int i = 0; i < rounds; i++)
        {
            currentRound = i;
            simulateRound();
        }
    }

    public void simulateRound()
    {
        // To get random questioning order.
        Collections.shuffle(investors);

        // Questioning investors
        for(Investor investor : investors)
        {
            Offer offer = investor.createOffer(this, time);

            if(offer == null)
                continue;

            time++;

            if(offer.getOfferType() == Offer.OfferType.PURCHASE)
            {
                purchaseOffers.add(offer);
            }
            else
            {
                saleOffers.add(offer);
            }
        }

        // Executing offers
        Collections.sort(purchaseOffers, Collections.reverseOrder());
        Collections.sort(saleOffers);

        int purchasePtr = 0;

        // Until all purchases are processed
        while(purchasePtr != purchaseOffers.size())
        {
            Offer purchaseOffer = purchaseOffers.get(purchasePtr);
            Investor purchaseInvestor = purchaseOffer.getInvestor();
            String shareID = purchaseOffer.getShareID();

            int salePtr = 0;
            boolean purchaseCompleted = false;

            while(salePtr != saleOffers.size())
            {
                Offer saleOffer = saleOffers.get(salePtr);
                Investor saleInvestor = saleOffer.getInvestor();

                if(!shareID.equals(saleOffer.getShareID()))
                {
                    salePtr++;
                }
                else
                {
                    int price = purchaseOffer.getSubmissionTime() < saleOffer.getSubmissionTime() ? purchaseOffer.getPriceLimit() : saleOffer.getPriceLimit();
                    // All shares an investor CAN buy but no more than offered.
                    int amount = Math.min(purchaseInvestor.getMoney() / price, Math.min(Math.min(purchaseOffer.getSharesAmount(), saleOffer.getSharesAmount()), saleInvestor.getShareAmounts().get(shareID)));

                    purchaseOffer.addSharesAmount(-amount);
                    saleOffer.addSharesAmount(-amount);
                    purchaseInvestor.addMoney(-amount * price);
                    saleInvestor.addMoney(amount * price);
                    purchaseInvestor.addShares(shareID, amount);
                    saleInvestor.addShares(shareID, -amount);

                    // Saving share price
                    sharePrices.put(shareID, price);

                    if(saleOffer.getSharesAmount() == 0)
                    {
                        saleOffers.remove(salePtr);
                    }
                    else
                    {
                        purchaseOffers.remove(purchasePtr);
                        purchaseCompleted = true;
                        break;
                    }
                }
            }

            if(!purchaseCompleted)
                purchasePtr++;
        }

        // Clearing offers
        clearExpiredOffers(purchaseOffers);
        clearExpiredOffers(saleOffers);

        // Adding current prices to price history
        priceHistory.add(new HashMap<>(sharePrices));
    }

    private void clearExpiredOffers(ArrayList<Offer> offers)
    {
        for(int i = 0; i < offers.size(); i++)
        {
            Offer offer = offers.get(i);

            if(offer.getOfferDeadline() == Offer.OfferDeadline.IMMEDIATE)
            {
                offers.remove(i);
                i--; // To not lose checking any elements.
            }
            else if(offer.getOfferDeadline() == Offer.OfferDeadline.TILL_ROUND)
            {
                if(offer.getMaxRound() == currentRound)
                {
                    offers.remove(i);
                    i--; // To not lose checking any elements.
                }
            }
        }
    }
}
