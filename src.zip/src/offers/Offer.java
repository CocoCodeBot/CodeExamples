package offers;

import investors.Investor;

public class Offer implements Comparable<Offer>
{
    public enum OfferType
    {
        PURCHASE, SALE;
    }

    public enum OfferDeadline
    {
        IMMEDIATE, NO_DEADLINE, TILL_ROUND
    }

    private Investor investor;
    private String shareID; // Share's ID
    private final OfferType offerType;
    private final OfferDeadline offerDeadline;
    private final int submissionTime;
    private int sharesAmount;
    private int priceLimit;
    private int maxRound;

    public Offer(Investor investor, String shareID, OfferType offerType, OfferDeadline offerDeadline, int submissionTime, int sharesAmount, int priceLimit)
    {
        this.investor = investor;
        this.shareID = shareID;
        this.offerType = offerType;
        this.offerDeadline = offerDeadline;
        this.submissionTime = submissionTime;
        this.sharesAmount = sharesAmount;
        this.priceLimit = priceLimit;
    }

    public Investor getInvestor()
    {
        return investor;
    }

    public OfferType getOfferType()
    {
        return offerType;
    }

    public String getShareID()
    {
        return shareID;
    }

    public OfferDeadline getOfferDeadline()
    {
        return offerDeadline;
    }

    public int getSubmissionTime()
    {
        return submissionTime;
    }

    public int getSharesAmount()
    {
        return sharesAmount;
    }

    public int getPriceLimit()
    {
        return priceLimit;
    }

    public int getMaxRound()
    {
        return maxRound;
    }

    public void setMaxRound(int round)
    {
        maxRound = round;
    }

    // q < 0 if you want to subtract.
    public void addSharesAmount(int q)
    {
        sharesAmount += q;
    }

    public int compareTo(Offer other)
    {
        return priceLimit - other.getPriceLimit();
    }
}
