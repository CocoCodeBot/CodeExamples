package main;

import investors.*;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import simulation.Market;

public class Main
{
    public static void main(String[] args)
    {
        ArrayList<Investor> investors = new ArrayList<>();
        HashMap<String, Integer> sharePrices = new HashMap<>();

        try
        {
            File file = new File("src/main/input.txt");

            Scanner fileScanner = new Scanner(file);

            int lineNum = 0;

            while (fileScanner.hasNextLine())
            {
                String line = fileScanner.nextLine();

                if(line.charAt(0) == '#')
                    continue;

                Scanner lineScanner = new Scanner(line);

                if(lineNum == 0)
                {
                    int id = 0;

                    while(lineScanner.hasNext())
                    {
                        String s = lineScanner.next();

                        if(s.equals("R"))
                        {
                            investors.add((new RandomInvestor(id)));
                        }
                        else
                        {
                            investors.add(new SMAInvestor(id));
                        }

                        id++;
                    }
                    
                    lineNum++;
                }
                else if(lineNum == 1)
                {
                    while(lineScanner.hasNext())
                    {
                        String s = lineScanner.next();
                        sharePrices.put(getString(s), getInteger(s));
                    }

                    lineNum++;
                }
                else
                {
                    int money = lineScanner.nextInt();

                    for(Investor investor : investors)
                    {
                        investor.setMoney(money);
                    }

                    while(lineScanner.hasNext())
                    {
                        String s = lineScanner.next();

                        for(Investor investor : investors)
                        {
                            investor.setShareAmount(getString(s), getInteger(s));
                        }
                    }

                }
            }

            fileScanner.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }

        /*
        System.out.println();

        for(String i : sharePrices.keySet())
        {
            System.out.println(i + ":" + sharePrices.get(i));
        }
        */

        Market market = new Market(investors, sharePrices, Integer.parseInt(args[1]));

        market.simulate();

        for(Investor investor : investors)
        {
            System.out.println(investor.toString());
        }

        /*System.out.println();

        for(String i : market.getSharePrices().keySet())
        {
            System.out.println("Final price of " + i + " was: " + market.getSharePrices().get(i));
        }*/
    }

    // From format String:Integer;
    private static String getString(String s)
    {
        int idx = -1;

        for(int i = 0; i < s.length(); i++)
        {
            if(s.charAt(i) == ':')
            {
                idx = i;
                break;
            }
        }

        return s.substring(0, idx);
    }

    // From format String:Integer;
    private static Integer getInteger(String s)
    {
        int idx = -1;

        for(int i = 0; i < s.length(); i++)
        {
            if(s.charAt(i) == ':')
            {
                idx = i + 1;
                break;
            }
        }

        return Integer.parseInt(s.substring(idx));
    }
}