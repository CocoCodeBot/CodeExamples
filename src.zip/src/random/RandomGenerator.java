package random;

import java.util.Random;

public class RandomGenerator
{
    // Random int from min inclusive to max exclusive.
    public static int randomInt(int min, int max)
    {
        Random random = new Random();
        return random.nextInt(max - min) + min;
    }
}
